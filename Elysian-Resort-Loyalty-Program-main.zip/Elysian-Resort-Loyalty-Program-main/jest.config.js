// jest.config.js for CommonJS compatibility
module.exports = {
  testEnvironment: 'node',
};
